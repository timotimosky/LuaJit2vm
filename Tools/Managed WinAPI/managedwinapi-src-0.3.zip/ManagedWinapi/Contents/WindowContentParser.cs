/*
 * ManagedWinapi - A collection of .NET components that wrap PInvoke calls to 
 * access native API by managed code. http://mwinapi.sourceforge.net/
 * Copyright (C) 2006 Michael Schierl
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; see the file COPYING. if not, visit
 * http://www.gnu.org/licenses/lgpl.html or write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */
using System;

namespace ManagedWinapi.Windows.Contents
{
    internal abstract class WindowContentParser
    {
        internal abstract bool CanParseContent(SystemWindow sw);
        internal abstract WindowContent ParseContent(SystemWindow sw);

        internal static WindowContent Parse(SystemWindow sw)
        {
            WindowContentParser parser = ContentParserRegistry.Instance.GetParser(sw);
            if (parser == null) return null;
            return parser.ParseContent(sw);
        }
    }
}
